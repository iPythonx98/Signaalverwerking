/*******************************************************************************
* File Name: Codec_en.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Codec_en_H) /* Pins Codec_en_H */
#define CY_PINS_Codec_en_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Codec_en_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Codec_en__PORT == 15 && ((Codec_en__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    Codec_en_Write(uint8 value) ;
void    Codec_en_SetDriveMode(uint8 mode) ;
uint8   Codec_en_ReadDataReg(void) ;
uint8   Codec_en_Read(void) ;
uint8   Codec_en_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Codec_en_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Codec_en_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Codec_en_DM_RES_UP          PIN_DM_RES_UP
#define Codec_en_DM_RES_DWN         PIN_DM_RES_DWN
#define Codec_en_DM_OD_LO           PIN_DM_OD_LO
#define Codec_en_DM_OD_HI           PIN_DM_OD_HI
#define Codec_en_DM_STRONG          PIN_DM_STRONG
#define Codec_en_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Codec_en_MASK               Codec_en__MASK
#define Codec_en_SHIFT              Codec_en__SHIFT
#define Codec_en_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Codec_en_PS                     (* (reg8 *) Codec_en__PS)
/* Data Register */
#define Codec_en_DR                     (* (reg8 *) Codec_en__DR)
/* Port Number */
#define Codec_en_PRT_NUM                (* (reg8 *) Codec_en__PRT) 
/* Connect to Analog Globals */                                                  
#define Codec_en_AG                     (* (reg8 *) Codec_en__AG)                       
/* Analog MUX bux enable */
#define Codec_en_AMUX                   (* (reg8 *) Codec_en__AMUX) 
/* Bidirectional Enable */                                                        
#define Codec_en_BIE                    (* (reg8 *) Codec_en__BIE)
/* Bit-mask for Aliased Register Access */
#define Codec_en_BIT_MASK               (* (reg8 *) Codec_en__BIT_MASK)
/* Bypass Enable */
#define Codec_en_BYP                    (* (reg8 *) Codec_en__BYP)
/* Port wide control signals */                                                   
#define Codec_en_CTL                    (* (reg8 *) Codec_en__CTL)
/* Drive Modes */
#define Codec_en_DM0                    (* (reg8 *) Codec_en__DM0) 
#define Codec_en_DM1                    (* (reg8 *) Codec_en__DM1)
#define Codec_en_DM2                    (* (reg8 *) Codec_en__DM2) 
/* Input Buffer Disable Override */
#define Codec_en_INP_DIS                (* (reg8 *) Codec_en__INP_DIS)
/* LCD Common or Segment Drive */
#define Codec_en_LCD_COM_SEG            (* (reg8 *) Codec_en__LCD_COM_SEG)
/* Enable Segment LCD */
#define Codec_en_LCD_EN                 (* (reg8 *) Codec_en__LCD_EN)
/* Slew Rate Control */
#define Codec_en_SLW                    (* (reg8 *) Codec_en__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Codec_en_PRTDSI__CAPS_SEL       (* (reg8 *) Codec_en__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Codec_en_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Codec_en__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Codec_en_PRTDSI__OE_SEL0        (* (reg8 *) Codec_en__PRTDSI__OE_SEL0) 
#define Codec_en_PRTDSI__OE_SEL1        (* (reg8 *) Codec_en__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Codec_en_PRTDSI__OUT_SEL0       (* (reg8 *) Codec_en__PRTDSI__OUT_SEL0) 
#define Codec_en_PRTDSI__OUT_SEL1       (* (reg8 *) Codec_en__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Codec_en_PRTDSI__SYNC_OUT       (* (reg8 *) Codec_en__PRTDSI__SYNC_OUT) 


#if defined(Codec_en__INTSTAT)  /* Interrupt Registers */

    #define Codec_en_INTSTAT                (* (reg8 *) Codec_en__INTSTAT)
    #define Codec_en_SNAP                   (* (reg8 *) Codec_en__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Codec_en_H */


/* [] END OF FILE */
